# -*- coding: utf-8 -*-

from __future__ import print_function

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.config import (
    getConfigListEntry, ConfigFloat, ConfigSelection,
    ConfigText, ConfigInteger
)
from enigma import eTimer
from Screens.MessageBox import MessageBox

import xml.etree.ElementTree as ET
import os
import tempfile
import shutil
import threading
import json
import time
import requests

# Disable SSL warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Main-thread callback dispatcher
# ---------------------------------------------------------------------------
try:
    from enigma import eCallOnMainThread as _e2_call_main
    def _call_main(fn, *args):
        _e2_call_main(fn, *args)
except ImportError:
    try:
        from twisted.internet import reactor as _reactor
        def _call_main(fn, *args):
            _reactor.callFromThread(fn, *args)
    except ImportError:
        import sys
        print("[SatManager] WARNING: no async dispatcher found – using sync fallback",
              file=sys.stderr)
        def _call_main(fn, *args):
            fn(*args)

from enum import Enum, auto

try:
    from Components.NimManager import nimmanager
    _NIM_AVAILABLE = True
except ImportError:
    nimmanager = None
    _NIM_AVAILABLE = False
    print("[SatManager] NimManager not available – transponder reload requires restart")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PATH_ENIGMA2 = "/etc/enigma2/satellites.xml"
PATH_TUXBOX  = "/etc/tuxbox/satellites.xml"
ACTIVE_XML_PATH = None
FILTERS_FILE = "/etc/enigma2/satmanager_filters.json"
BACKUP_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/SatelliteManager/backup"
XML_PERMS   = 0o644
MAX_BACKUP  = 1
MAX_DELETE_NAMES_SHOWN = 20
TP_PAGE_SIZE = 20
SAT_PAGE_SIZE = 10
SAVE_TIMEOUT = 5

# Band frequency ranges (in MHz)
BAND_RANGES = {
    "C": (3400, 4200),
    "Ku": (10700, 12750),
    "Ka": (18200, 22200)
}

# Download sources
DOWNLOAD_SOURCES = {
    "OpenPLi": "https://raw.githubusercontent.com/OpenPLi/tuxbox-xml/refs/heads/master/xml/satellites.xml",
    "Oe-Alliance": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/satellites.xml",
    "Lyngsat": "https://gitlab.com/eliesat/settings/-/raw/main/lyngsat/satellites.xml?ref_type=heads",
    "ElieSat": "https://gitlab.com/eliesat/settings/-/raw/main/eliesat/satellites.xml?ref_type=heads"
}

# Geographic regions based on orbital position (in degrees * 10)
GEOGRAPHIC_REGIONS = {
    "Asia": {
        "range": [(730, 1800), (-1800, -1600)],  # 73°E to 180°E and 180°W to 160°W
        "name": "Asia"
    },
    "Europe": {
        "range": [(0, 730)],     # 0°E to 73°E
        "name": "Europe"
    },
    "Atlantic": {
        "range": [(-610, 0)],    # 0°W to 61°W
        "name": "Atlantic"
    },
    "America": {
        "range": [(-1600, -610)], # 61°W to 160°W
        "name": "America"
    }
} 
# ---------------------------------------------------------------------------
# Global file lock and save state tracking
# ---------------------------------------------------------------------------
_file_lock = threading.Lock()
_save_in_progress = False
_save_thread = None

def release_file_lock():
    global _save_in_progress, _save_thread
    print("[SatManager] Releasing file resources...")
    
    if _save_in_progress and _save_thread and _save_thread.is_alive():
        print("[SatManager] Waiting for pending save operation to complete...")
        _save_thread.join(timeout=SAVE_TIMEOUT)
        if _save_thread.is_alive():
            print("[SatManager] WARNING: Save operation timed out!")
    
    try:
        if _file_lock.locked():
            _file_lock.release()
            print("[SatManager] File lock released")
    except RuntimeError:
        pass
    
    _save_in_progress = False
    _save_thread = None
    print("[SatManager] File resources released")

def reload_nim_transponders():
    """Reload NimManager transponders from satellites.xml"""
    if _NIM_AVAILABLE and nimmanager:
        try:
            nimmanager.readTransponders()
            print("[SatManager] NimManager readTransponders() called")
            return True
        except Exception as exc:
            print("[SatManager] NimManager error: {}".format(exc))
    return False

def show_restart_warning(session, operation):
    """Show warning message that GUI restart is required for changes to take effect."""
    msg = "Warning!\n\n" + \
          "You have {} satellite(s)/file.\n\n".format(operation) + \
          "The changes have been saved to satellites.xml.\n\n" + \
          "However, to see the updated satellite list in:\n" + \
          "• Tuner Settings\n" + \
          "• SignalFinder / SatFinder\n\n" + \
          "You need to restart the GUI (Enigma2 interface).\n\n" + \
          "Do you want to restart the GUI now?"
    
    from Screens.Standby import TryQuitMainloop
    session.openWithCallback(lambda answer: _restart_gui(answer, session), MessageBox, msg, MessageBox.TYPE_YESNO)

def _restart_gui(answer, session):
    if answer:
        from enigma import quitMainloop
        quitMainloop(3)

def get_geographic_region(orbital_pos):
    """Determine geographic region based on orbital position (position * 10)"""
    try:
        pos = int(orbital_pos)
        for region, info in GEOGRAPHIC_REGIONS.items():
            ranges = info["range"]
            for r in ranges:
                min_pos, max_pos = r
                if min_pos <= pos <= max_pos:
                    return region
        return "Other"
    except (ValueError, TypeError):
        return "Unknown"
# ---------------------------------------------------------------------------
# UI Mode
# ---------------------------------------------------------------------------
class UIMode(Enum):
    SAT_MODE_NORMAL      = auto()
    SAT_MODE_MULTI_SELECT = auto()
    TP_MODE_NORMAL       = auto()
    TP_MODE_MULTI_SELECT = auto()

# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------
def format_position(pos):
    try:
        degree    = abs(int(pos)) / 10.0
        direction = "E" if int(pos) >= 0 else "W"
        return "{:.1f}{}".format(degree, direction)
    except (ValueError, TypeError):
        return "0.0E"

def format_frequency_khz(freq_raw, default="0", band_type=None):
    """Format frequency from kHz to MHz."""
    try:
        val = int(float(freq_raw))
        freq_mhz = val // 1000
        return str(freq_mhz)
    except (ValueError, TypeError, AttributeError):
        return default

def validate_frequency_for_band(freq_mhz, band_type):
    """Validate that frequency is within the allowed range for the band."""
    if band_type not in BAND_RANGES:
        return True, ""
    
    min_freq, max_freq = BAND_RANGES[band_type]
    if freq_mhz < min_freq or freq_mhz > max_freq:
        return False, "Frequency {} MHz is outside {} band range ({}-{} MHz)".format(
            freq_mhz, band_type, min_freq, max_freq)
    return True, ""

def get_band_type(frequency_khz):
    try:
        if not frequency_khz:
            return "Unknown"
        freq_mhz = float(frequency_khz) / 1000.0
        if 10700 <= freq_mhz <= 12750:
            return "Ku"
        if 3400 <= freq_mhz <= 4200:
            return "C"
        if 18200 <= freq_mhz <= 22200:
            return "Ka"
        return "Other"
    except (ValueError, TypeError):
        return "Unknown"

def _cache_band_for_satellite(sat):
    cached = sat.get("_cached_band")
    if cached is not None:
        return cached
    explicit_band = sat.get("band")
    if explicit_band in ("Ku", "C", "Ka"):
        sat.set("_cached_band", explicit_band)
        return explicit_band
    priority = ("Ku", "C", "Ka")
    found = set()
    try:
        for tp in sat.findall("transponder"):
            try:
                freq_int = int(tp.get("frequency", "0"))
                if freq_int > 0:
                    found.add(get_band_type(freq_int))
            except (ValueError, TypeError):
                continue
        for band in priority:
            if band in found:
                sat.set("_cached_band", band)
                return band
    except Exception:
        pass
    sat.set("_cached_band", "Other")
    return "Other"

def get_band_type_from_sat(sat):
    cached = sat.get("_cached_band")
    if cached is not None:
        return cached
    return _cache_band_for_satellite(sat)

# ---------------------------------------------------------------------------
# XML I/O with proper file handling
# ---------------------------------------------------------------------------
def _read_xml_bytes(xml_path):
    with _file_lock:
        for enc in ("utf-8", "latin-1", "iso-8859-1"):
            try:
                with open(xml_path, "r", encoding=enc) as fh:
                    content = fh.read()
                return content
            except UnicodeDecodeError:
                continue
        with open(xml_path, "rb") as fh:
            content = fh.read().decode("utf-8", errors="replace")
    return content

def _build_pretty_xml(root):
    try:
        ET.indent(root, space="  ")
        data = ET.tostring(root, encoding="unicode", xml_declaration=False)
        return ('<?xml version="1.0" encoding="utf-8"?>\n' + data).encode("utf-8")
    except AttributeError:
        def _indent(elem, level=0):
            pad = "\n" + "  " * level
            if len(elem):
                if not elem.text or not elem.text.strip():
                    elem.text = pad + "  "
                if not elem.tail or not elem.tail.strip():
                    elem.tail = pad
                for child in elem:
                    _indent(child, level + 1)
                if not child.tail or not child.tail.strip():
                    child.tail = pad
            else:
                if level and (not elem.tail or not elem.tail.strip()):
                    elem.tail = pad
        _indent(root)
        data = ET.tostring(root, encoding="unicode", xml_declaration=False)
        return ('<?xml version="1.0" encoding="utf-8"?>\n' + data).encode("utf-8")

def _rotate_backups(xml_path, max_backups=MAX_BACKUP):
    """Keep only one backup in the backup folder"""
    if not os.path.exists(BACKUP_DIR):
        try:
            os.makedirs(BACKUP_DIR, mode=0o755)
            print("[SatManager] Created backup directory: {}".format(BACKUP_DIR))
        except OSError as e:
            print("[SatManager] Could not create backup directory: {}".format(e))
            return
    
    backup_path = os.path.join(BACKUP_DIR, os.path.basename(xml_path) + ".bak")
    
    if os.path.exists(backup_path):
        try:
            os.remove(backup_path)
            print("[SatManager] Removed old backup: {}".format(backup_path))
        except OSError as e:
            print("[SatManager] Could not remove old backup: {}".format(e))
    
    if os.path.exists(xml_path):
        try:
            shutil.copy2(xml_path, backup_path)
            print("[SatManager] Created backup: {}".format(backup_path))
        except OSError as e:
            print("[SatManager] Could not create backup: {}".format(e))

def save_safely(xml_tree, xml_path):
    directory = os.path.dirname(xml_path) or "."
    if not os.access(directory, os.W_OK):
        raise OSError("Cannot write to directory: insufficient permissions")
    
    with _file_lock:
        root = xml_tree.getroot()
        xml_bytes = _build_pretty_xml(root)
        tmp_path = None
        try:
            fd, tmp_path = tempfile.mkstemp(dir=directory, suffix=".xml.tmp")
            try:
                with os.fdopen(fd, "wb") as fh:
                    fh.write(xml_bytes)
                    fh.flush()
                    os.fsync(fh.fileno())
            except:
                os.close(fd)
                raise
            
            if os.path.exists(xml_path):
                _rotate_backups(xml_path)
            shutil.move(tmp_path, xml_path)
            tmp_path = None
            os.chmod(xml_path, XML_PERMS)
            print("[SatManager] Saved: {}".format(xml_path))
            return True
        except Exception as exc:
            print("[SatManager] Save error: {}".format(exc))
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
            raise
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

def parse_satellites(xml_path):
    if not os.path.exists(xml_path):
        print("[SatManager] {} not found".format(xml_path))
        return None, []
    
    try:
        content = _read_xml_bytes(xml_path)
        
        if not content or not content.strip():
            print("[SatManager] {} is empty".format(xml_path))
            root = ET.Element("satellites")
            tree = ET.ElementTree(root)
            return tree, []
        
        root = ET.fromstring(content)
        tree = ET.ElementTree(root)
        sats = root.findall("sat")
        
        for sat in sats:
            _cache_band_for_satellite(sat)
            
        print("[SatManager] Loaded {} satellites from {}".format(len(sats), xml_path))
        return tree, sats
        
    except ET.ParseError as exc:
        print("[SatManager] XML parse error in {}: {}".format(xml_path, exc))
        root = ET.Element("satellites")
        tree = ET.ElementTree(root)
        return tree, []
        
    except IOError as exc:
        print("[SatManager] IO error reading {}: {}".format(xml_path, exc))
        root = ET.Element("satellites")
        tree = ET.ElementTree(root)
        return tree, []
        
    except Exception as exc:
        print("[SatManager] General parse error in {}: {}".format(xml_path, exc))
        root = ET.Element("satellites")
        tree = ET.ElementTree(root)
        return tree, []

# ---------------------------------------------------------------------------
# Filter settings
# ---------------------------------------------------------------------------
def _load_filter_settings():
    default = {"band": "All", "direction": "All", "region": "All", "xml_source": "auto"}
    if not os.path.exists(FILTERS_FILE):
        return default
    try:
        with open(FILTERS_FILE, "r") as f:
            data = json.load(f)
            return {
                "band": data.get("band", "All"),
                "direction": data.get("direction", "All"),
                "region": data.get("region", "All"),
                "xml_source": data.get("xml_source", "auto")
            }
    except Exception as e:
        print("[SatManager] Error loading filters: {}".format(e))
        return default

def _save_filter_settings(band, direction, region=None, xml_source=None):
    try:
        directory = os.path.dirname(FILTERS_FILE)
        if directory and not os.path.exists(directory):
            os.makedirs(directory, mode=0o755, exist_ok=True)
        data = {"band": band, "direction": direction, "region": region if region else "All"}
        if xml_source is not None:
            data["xml_source"] = xml_source
        with open(FILTERS_FILE, "w") as f:
            json.dump(data, f)
        print("[SatManager] Filters saved: band={}, direction={}, region={}, xml_source={}".format(band, direction, region, xml_source))
    except Exception as e:
        print("[SatManager] Error saving filters: {}".format(e))

# ---------------------------------------------------------------------------
# Filter screens
# ---------------------------------------------------------------------------
_FILTER_SKIN_TEMPLATE = """
<screen name="{name}" flags="wfNoBorder" position="center,center"
        size="800,600" backgroundColor="#1C1C1E" cornerRadius="20">
    <widget name="listBg" position="20,70" size="760,420" backgroundColor="#2C2C2E" cornerRadius="12" zPosition="1" />
    <widget name="title"     position="20,20"  size="760,40"  font="Regular;30"
            foregroundColor="#FFFFFF" backgroundColor="#1C1C1E" halign="center" />
    <widget name="list"     itemHeight="50" position="40,90"  size="700,380" scrollbarMode="showOnDemand"
            backgroundColor="2E2E2C" foregroundColor="#FFFFFF" zPosition="5"
            foregroundColorSelected="#FFFFFF" backgroundColorSelected="#0A84FF"
            font="Regular;40" transparent="1" />
    <widget name="key_red"   position="50,510" size="300,50"
            backgroundColor="#3A3A3C" foregroundColor="#FF453A"
            valign="center" halign="center" font="Regular;30" cornerRadius="10" />
    <widget name="key_green" position="450,510" size="300,50"
            backgroundColor="#3A3A3C" foregroundColor="#30D158"
            valign="center" halign="center" font="Regular;30" cornerRadius="10" />
</screen>
"""

class _BaseFilterScreen(Screen):
    _OPTIONS       = []
    _TITLE         = "Select"
    _CONFIRM_LABEL = "Apply"
    _VALID_VALUES  = None
    
    def __init__(self, session, current_value):
        Screen.__init__(self, session)
        self.current_value = current_value
        self["title"]     = Label(self._TITLE)
        self["key_red"]   = Button("Cancel")
        self["key_green"] = Button(self._CONFIRM_LABEL)
        self["list"]      = MenuList(list(self._OPTIONS), enableWrapAround=True)
        self["listBg"]    = Label("")
        
        for i, (_, val) in enumerate(self._OPTIONS):
            if val == current_value:
                self["list"].moveToIndex(i)
                break
        
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "NavigationActions"],
            {
                "ok": self._confirm,
                "green": self._confirm,
                "cancel": self._cancel,
                "red": self._cancel,
                "up": self._up,
                "down": self._down,
                "left": self._left,
                "right": self._right,
            },
            -1
        )
    
    def _up(self):
        if self["list"].instance is not None and self["list"].list:
            self["list"].up()
    
    def _down(self):
        if self["list"].instance is not None and self["list"].list:
            self["list"].down()
    
    def _left(self):
        if self["list"].instance is not None:
            self["list"].pageUp()
    
    def _right(self):
        if self["list"].instance is not None:
            self["list"].pageDown()
    
    def _confirm(self):
        cur = self["list"].getCurrent()
        if cur:
            value = cur[1]
            if self._VALID_VALUES is None or value in self._VALID_VALUES:
                self.close(value)
                return
        self.close(self.current_value)
    
    def _cancel(self):
        self.close(None)

class FilterMenuScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="FilterMenuScreen")
    _OPTIONS = [
        ("Band Filter", "band"),
        ("Direction Filter", "direction"),
        ("Geographic Region ", "region"),
        ("More Options", "xml"),
    ]
    _TITLE         = "Satellite Manager - Menu"
    _CONFIRM_LABEL = "Select"
    _VALID_VALUES  = frozenset({"band", "direction", "region", "xml"})

class BandFilterScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="BandFilterScreen")
    _OPTIONS = [
        ("All Bands", "All"),
        ("Ku Band (10.7-12.75 GHz)", "Ku"),
        ("C Band (3.4-4.2 GHz)", "C"),
        ("Ka Band (18.2-22.2 GHz)", "Ka")
    ]
    _TITLE        = "Select Band Type"
    _VALID_VALUES = frozenset({"All", "Ku", "C", "Ka"})

class DirectionFilterScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="DirectionFilterScreen")
    _OPTIONS = [
        ("All", "All"),
        ("East", "East"),
        ("West", "West")
    ]
    _TITLE        = "Select Direction"
    _VALID_VALUES = frozenset({"All", "East", "West"})

class RegionFilterScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="RegionFilterScreen")
    _OPTIONS = [
        ("All Regions", "All"),
        ("Asia", "Asia"),
        ("Europe", "Europe"),
        ("Atlantic", "Atlantic"),
        ("America", "America")
    ]
    _TITLE        = "Select Geographic Region"
    _VALID_VALUES = frozenset({"All", "Asia", "Europe", "Atlantic", "America"})

# ---------------------------------------------------------------------------
# XML Source Options Screens
# ---------------------------------------------------------------------------

class XMLSourceMenuScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="XMLSourceMenuScreen")
    _OPTIONS = [
        ("Select file Source", "select"),
        ("Show Current file Info", "info"),
        ("Download", "download"),
        ("Restore", "restore"),
    ]
    _TITLE         = "Satellites.xml Manager"
    _CONFIRM_LABEL = "Select"
    _VALID_VALUES  = frozenset({"select", "info", "download", "restore"})

class DownloadSourceScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="DownloadSourceScreen")
    _TITLE = "Select Download Source"
    _CONFIRM_LABEL = "Download"
    
    def __init__(self, session, current_value):
        self._OPTIONS = [(name, name) for name in DOWNLOAD_SOURCES.keys()]
        self._VALID_VALUES = frozenset(DOWNLOAD_SOURCES.keys())
        _BaseFilterScreen.__init__(self, session, current_value)

class DownloadDestinationScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="DownloadDestinationScreen")
    _TITLE = "Save to"
    _CONFIRM_LABEL = "Confirm"
    
    def __init__(self, session, current_value, source):
        self._OPTIONS = [
            ("/etc/enigma2/satellites.xml", "enigma2"),
            ("/etc/tuxbox/satellites.xml", "tuxbox"),
        ]
        self._VALID_VALUES = frozenset({"enigma2", "tuxbox"})
        self.source = source
        current = "enigma2" if ACTIVE_XML_PATH == PATH_ENIGMA2 else "tuxbox" if ACTIVE_XML_PATH == PATH_TUXBOX else None
        _BaseFilterScreen.__init__(self, session, current)
    
    def _confirm(self):
        cur = self["list"].getCurrent()
        if cur:
            value = cur[1]
            if self._VALID_VALUES is None or value in self._VALID_VALUES:
                self.close(value)
                return
        self.close(None)

class XMLSourceSelectScreen(_BaseFilterScreen):
    skin = _FILTER_SKIN_TEMPLATE.format(name="XMLSourceSelectScreen")
    _TITLE = "Select satellites.xml Source"
    _CONFIRM_LABEL = "Apply"
    
    def __init__(self, session, current_value):
        global ACTIVE_XML_PATH
        
        self._OPTIONS = []
        
        enigma2_exists = os.path.exists(PATH_ENIGMA2)
        enigma2_status = " (exists)" if enigma2_exists else " (will be copied)"
        enigma2_active = " <- current" if ACTIVE_XML_PATH == PATH_ENIGMA2 else ""
        self._OPTIONS.append(("/etc/enigma2/satellites.xml{}{}".format(enigma2_status, enigma2_active), "enigma2"))
        
        tuxbox_exists = os.path.exists(PATH_TUXBOX)
        tuxbox_status = " (exists)" if tuxbox_exists else " (will be copied)"
        tuxbox_active = " <- current" if ACTIVE_XML_PATH == PATH_TUXBOX else ""
        self._OPTIONS.append(("/etc/tuxbox/satellites.xml{}{}".format(tuxbox_status, tuxbox_active), "tuxbox"))
        
        self._VALID_VALUES = frozenset({"enigma2", "tuxbox"})
        current = "enigma2" if ACTIVE_XML_PATH == PATH_ENIGMA2 else "tuxbox" if ACTIVE_XML_PATH == PATH_TUXBOX else None
        
        _BaseFilterScreen.__init__(self, session, current)

class XMLPathInfoScreen(Screen):
    skin = """
    <screen name="XMLPathInfoScreen" flags="wfNoBorder" position="center,center"
            size="1000,720" scrollbarMode="showOnDemand" backgroundColor="#1C1C1E" cornerRadius="20">
        <widget name="title" position="20,20" size="810,45" font="Regular;28"
                foregroundColor="#FFFFFF" backgroundColor="#1C1C1E" halign="center" />
        <widget name="info" position="30,85" size="840,580" font="Regular;20"
                foregroundColor="#CCCCCC" backgroundColor="#2C2C2E" cornerRadius="12"
                valign="top" halign="left" />
        <widget name="key_green" position="275,660" size="300,50"
                backgroundColor="#3A3A3C" foregroundColor="#30D158"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
    </screen>
    """
    def __init__(self, session, info_text):
        Screen.__init__(self, session)
        self["title"] = Label("Satellites.xml Information")
        self["info"] = Label(info_text)
        self["key_green"] = Button("OK")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"ok": self.close, "green": self.close, "cancel": self.close},
            -1
        )

# ---------------------------------------------------------------------------
# Add / Edit Satellite
# ---------------------------------------------------------------------------
class AddSatelliteScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="AddSatelliteScreen" flags="wfNoBorder" position="center,center"
            size="700,500" backgroundColor="#1C1C1E" cornerRadius="20">
        <widget name="title"     position="20,15"  size="660,40"  font="Regular;24"
                foregroundColor="#FFFFFF" backgroundColor="#1C1C1E" halign="center" />
        <widget name="config" itemHeight="50"   position="20,65"  size="660,350" backgroundColor="#2C2C2E"
                cornerRadius="15" font="Regular; 35" foregroundColor="#20FFFFFF" foregroundColorSelected="#FFFFFF" />
        <widget name="key_red"   position="20,435"  size="300,45"
                backgroundColor="#3A3A3C" foregroundColor="#FF453A"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
        <widget name="key_green" position="380,435" size="300,45"
                backgroundColor="#3A3A3C" foregroundColor="green"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
    </screen>
    """
    def __init__(self, session, existing_names=None):
        Screen.__init__(self, session)
        self.existing_names_lower = {n.lower() for n in (existing_names or [])}
        self["title"]     = Label("Enter Satellite Information")
        self["key_red"]   = Button("Cancel")
        self["key_green"] = Button("Add")
        self.sat_name  = ConfigText(default="", fixed_size=False)
        self.degree    = ConfigFloat(default=[13, 0], limits=[(0, 180), (0, 9)])
        self.direction = ConfigSelection(default="E", choices=[("E", "East"), ("W", "West")])
        self.band_type = ConfigSelection(default="Ku", choices=[
            ("Ku", "Ku Band (10.7-12.75 GHz)"),
            ("C", "C Band (3.4-4.2 GHz)"),
            ("Ka", "Ka Band (18.2-22.2 GHz)")
        ])
        cfg = [
            getConfigListEntry("Satellite Name:",       self.sat_name, "e.g. Hotbird 13E"),
            getConfigListEntry("Position (0-180 deg):", self.degree, "Orbital position in degrees"),
            getConfigListEntry("Direction:",             self.direction, "East or West"),
            getConfigListEntry("Band Type:",             self.band_type, "Select frequency band"),
        ]
        ConfigListScreen.__init__(self, cfg, session=session)
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {"ok": self._save, "save": self._save, "green": self._save,
             "cancel": self._cancel, "red": self._cancel},
            -1
        )
    def _validate(self):
        name = self.sat_name.value.strip()
        if not name:
            self.session.open(MessageBox, "Please enter a satellite name.", MessageBox.TYPE_ERROR)
            return False
        if name.lower() in self.existing_names_lower:
            self.session.open(MessageBox, "Satellite '{}' already exists!".format(name), MessageBox.TYPE_ERROR)
            return False
        return True
    def _save(self):
        if not self._validate():
            return
        name    = self.sat_name.value.strip()
        deg     = self.degree.value[0] + self.degree.value[1] / 10.0
        new_pos = int(deg * 10)
        if self.direction.value == "W":
            new_pos = -new_pos
        self.close((name, new_pos, self.band_type.value))
    def _cancel(self):
        self.close(None)

class SatelliteEditScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="SatelliteEditScreen" flags="wfNoBorder" position="center,center"
            size="700,500" backgroundColor="#1C1C1E" cornerRadius="20">
        <widget name="title"     position="20,15"  size="660,40"  font="Regular;24"
                foregroundColor="#FFFFFF" backgroundColor="#1C1C1E" halign="center" />
        <widget name="config" itemHeight="50"   position="20,65"  size="660,350" backgroundColor="#2C2C2E"
                cornerRadius="15" font="Regular; 35" foregroundColor="#20FFFFFF" foregroundColorSelected="#FFFFFF" />
        <widget name="key_red"   position="20,435"  size="300,45"
                backgroundColor="#3A3A3C" foregroundColor="#FF453A"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
        <widget name="key_green" position="380,435" size="300,45"
                backgroundColor="#3A3A3C" foregroundColor="green"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
    </screen>
    """
    def __init__(self, session, sat_name, current_degree, current_direction, current_band):
        Screen.__init__(self, session)
        self["title"]     = Label("Edit Satellite Information")
        self["key_red"]   = Button("Cancel")
        self["key_green"] = Button("Save")
        self.sat_name  = ConfigText(default=sat_name, fixed_size=False)
        self.degree    = ConfigFloat(default=[int(current_degree), int((current_degree % 1) * 10)], limits=[(0, 180), (0, 9)])
        self.direction = ConfigSelection(default=current_direction, choices=[("E", "East"), ("W", "West")])
        self.band_type = ConfigSelection(default=current_band, choices=[
            ("Ku", "Ku Band (10.7-12.75 GHz)"),
            ("C", "C Band (3.4-4.2 GHz)"),
            ("Ka", "Ka Band (18.2-22.2 GHz)")
        ])
        cfg = [
            getConfigListEntry("Satellite Name:",         self.sat_name),
            getConfigListEntry("Position (0-180 deg):", self.degree),
            getConfigListEntry("Direction:",               self.direction),
            getConfigListEntry("Band Type:",               self.band_type),
        ]
        ConfigListScreen.__init__(self, cfg, session=session)
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {"ok": self._save, "save": self._save, "green": self._save,
             "cancel": self._cancel, "red": self._cancel},
            -1
        )
    def _validate(self):
        name = self.sat_name.value.strip()
        if not name:
            self.session.open(MessageBox, "Satellite name cannot be empty.", MessageBox.TYPE_ERROR)
            return False
        return True
    def _save(self):
        if not self._validate():
            return
        deg = self.degree.value[0] + self.degree.value[1] / 10.0
        self.close((self.sat_name.value.strip(), deg, self.direction.value, self.band_type.value))
    def _cancel(self):
        self.close(None)

# ---------------------------------------------------------------------------
# Transponder editor
# ---------------------------------------------------------------------------
class TransponderEditScreen(ConfigListScreen, Screen):
    _gold_to_root = None
    _root_to_gold = None
    _tables_lock  = threading.Lock()
    skin = """
    <screen name="TransponderEditScreen" flags="wfNoBorder" position="center,center"
            size="800,680" backgroundColor="#1C1C1E" cornerRadius="20">
        <widget name="title"      position="20,15"  size="760,40"  font="Regular;24"
                foregroundColor="#FFFFFF" backgroundColor="#1C1C1E" halign="center" />
        <widget name="config"  itemHeight="50"   position="20,65"  size="760,530" backgroundColor="#2C2C2E"
                cornerRadius="15" font="Regular; 31" foregroundColor="#FFFFFF" />
        <widget name="key_red"    position="20,615"  size="240,45"
                backgroundColor="#3A3A3C" foregroundColor="#FF453A"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
        <widget name="key_green"  position="280,615" size="240,45"
                backgroundColor="#3A3A3C" foregroundColor="green"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
        <widget name="key_yellow" position="540,615" size="240,45"
                backgroundColor="#3A3A3C" foregroundColor="yellow"
                valign="center" halign="center" font="Regular;30" cornerRadius="10" />
    </screen>
    """
    @classmethod
    def _init_tables(cls):
        with cls._tables_lock:
            if cls._gold_to_root is not None:
                return
            max_val = 262143
            g2r = [0] * max_val
            r2g = {}
            x = 1
            for gold in range(max_val):
                g2r[gold] = x
                r2g[x]    = gold
                x = (((x ^ (x >> 7)) & 1) << 17) | (x >> 1)
            cls._gold_to_root = g2r
            cls._root_to_gold = r2g
    @classmethod
    def gold2root(cls, gold_code):
        cls._init_tables()
        if 0 <= gold_code < len(cls._gold_to_root):
            return cls._gold_to_root[gold_code]
        return None
    @classmethod
    def root2gold(cls, root_code):
        cls._init_tables()
        return cls._root_to_gold.get(root_code, None)
    _FEC_MAP = {0: "Auto", 1: "1/2", 2: "2/3", 3: "3/4", 4: "5/6", 5: "7/8", 6: "8/9", 7: "3/5", 8: "4/5", 9: "9/10"}
    _MOD_MAP = {0: "Auto", 1: "QPSK", 2: "8PSK", 3: "16APSK", 4: "32APSK"}
    def __init__(self, session, tp_element=None, is_new=False, band_type="Ku"):
        Screen.__init__(self, session)
        self.is_new = is_new
        self.band_type = band_type
        self["title"]     = Label("Transponder Configuration")
        self["key_red"]   = Button("Cancel")
        self["key_green"] = Button("Save")
        self["key_yellow"]= Button("Convert PLS")
        if is_new or tp_element is None:
            d_freq, d_sr, d_pol, d_fec, d_mod, d_sys = 10719.0, 27500, "0", "3", "2", "1"
            d_pls_code, d_pls_mode, d_t2mi_id, d_t2mi_pid, d_t2mi_plp = 0, "0", 0, 0, 0
        else:
            raw_freq = int(tp_element.get("frequency", "10719000"))
            d_freq = raw_freq / 1000.0
            d_sr = int(tp_element.get("symbol_rate", "27500000")) // 1000
            d_pol = tp_element.get("polarization", "0")
            d_fec = tp_element.get("fec_inner", "3")
            d_mod = tp_element.get("modulation", "2")
            d_sys = tp_element.get("system", "1")
            d_pls_code = int(tp_element.get("pls_code", "0"))
            d_pls_mode = tp_element.get("pls_mode", "0")
            d_t2mi_id = int(tp_element.get("t2mi_id", "0"))
            d_t2mi_pid = int(tp_element.get("t2mi_pid", "0"))
            d_t2mi_plp = int(tp_element.get("t2mi_plp", "0"))
        
        # Set min/max frequency based on band type
        min_freq, max_freq = BAND_RANGES.get(band_type, (3000, 22200))
        
        self.freq = ConfigFloat(default=[int(d_freq), int((d_freq % 1) * 10)], 
                                limits=[(min_freq, max_freq), (0, 9)])
        self.symbol_rate = ConfigInteger(default=d_sr, limits=(1000, 45000))
        self.polarization = ConfigSelection(default=d_pol, choices=[
            ("0", "Horizontal"),
            ("1", "Vertical"),
            ("2", "Left"),
            ("3", "Right")
        ])
        self.fec = ConfigSelection(default=d_fec, choices=[("0", "Auto"), ("1", "1/2"), ("2", "2/3"), ("3", "3/4"), ("4", "5/6"), ("5", "7/8"), ("6", "8/9"), ("7", "3/5"), ("8", "4/5"), ("9", "9/10")])
        self.modulation = ConfigSelection(default=d_mod, choices=[("0", "Auto"), ("1", "QPSK"), ("2", "8PSK"), ("3", "16APSK"), ("4", "32APSK")])
        self.system = ConfigSelection(default=d_sys, choices=[("0", "DVB-S"), ("1", "DVB-S2")])
        self.pls_mode = ConfigSelection(default=d_pls_mode, choices=[("0", "Root"), ("1", "Golden"), ("2", "Combo"), ("3", "Not set")])
        self.pls_code = ConfigInteger(default=d_pls_code, limits=(0, 262143))
        self.t2mi_id = ConfigInteger(default=d_t2mi_id, limits=(0, 65535))
        self.t2mi_pid = ConfigInteger(default=d_t2mi_pid, limits=(0, 8191))
        self.t2mi_plp = ConfigInteger(default=d_t2mi_plp, limits=(0, 255))
        
        range_info = "Allowed: {}-{} MHz".format(min_freq, max_freq)
        self.cfg_list = [
            getConfigListEntry("Frequency (MHz):", self.freq, range_info),
            getConfigListEntry("Symbol Rate (Ksym/s):", self.symbol_rate, "e.g. 27500"),
            getConfigListEntry("Polarization:", self.polarization),
            getConfigListEntry("FEC:", self.fec),
            getConfigListEntry("Modulation:", self.modulation),
            getConfigListEntry("System:", self.system),
            getConfigListEntry("PLS Mode (Multistream):", self.pls_mode),
            getConfigListEntry("PLS Code (0-262143):", self.pls_code),
            getConfigListEntry("T2-MI ID:", self.t2mi_id, "0 = disabled"),
            getConfigListEntry("T2-MI PID (0-8191):", self.t2mi_pid),
            getConfigListEntry("T2-MI PLP (0-255):", self.t2mi_plp),
        ]
        ConfigListScreen.__init__(self, self.cfg_list, session=session)
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {"ok": self._save, "save": self._save, "green": self._save,
             "cancel": self._cancel, "red": self._cancel,
             "yellow": self._convert_pls},
            -1
        )
    def _convert_pls(self):
        code = self.pls_code.value
        if code == 0:
            self.session.open(MessageBox, "PLS Code is zero - no conversion possible.", MessageBox.TYPE_INFO)
            return
        msg = "Convert PLS code:\n\nYes -> treat as Gold, convert to Root\nNo -> treat as Root, convert to Gold"
        self.session.openWithCallback(self._do_pls_conversion, MessageBox, msg, MessageBox.TYPE_YESNO)
    def _do_pls_conversion(self, answer):
        if answer is None:
            return
        code = self.pls_code.value
        if answer:
            result = self.gold2root(code)
            if result is None:
                self.session.open(MessageBox, "Conversion failed: invalid Gold code.", MessageBox.TYPE_ERROR)
                return
            label = "Gold {} -> Root {}".format(code, result)
        else:
            result = self.root2gold(code)
            if result is None:
                self.session.open(MessageBox, "Conversion failed: invalid Root code.", MessageBox.TYPE_ERROR)
                return
            label = "Root {} -> Gold {}".format(code, result)
        self.pls_code.value = result
        self.pls_code.setValue(result)
        self["config"].setList(self.cfg_list)
        self.session.open(MessageBox, "Converted: " + label, MessageBox.TYPE_INFO)
    def _validate(self, tp_data):
        errors = []
        try:
            freq = int(tp_data["frequency"])
            freq_mhz = freq // 1000
            valid, msg = validate_frequency_for_band(freq_mhz, self.band_type)
            if not valid:
                errors.append(msg)
            elif not (3400000 <= freq <= 22200000):
                errors.append("Frequency {} kHz out of global range (3400-22200 MHz)".format(freq))
        except (ValueError, TypeError, KeyError):
            errors.append("Invalid frequency value.")
        try:
            sr = int(tp_data["symbol_rate"])
            if not (1000000 <= sr <= 45000000):
                errors.append("Symbol rate out of range (1000-45000 Ksym/s).")
        except (ValueError, TypeError, KeyError):
            errors.append("Invalid symbol rate.")
        if tp_data.get("system") == "0" and tp_data.get("modulation") in ("2", "3", "4"):
            errors.append("DVB-S does not support 8PSK / 16APSK / 32APSK.")
        if tp_data.get("polarization") not in ("0", "1", "2", "3"):
            errors.append("Invalid polarization (must be 0=H, 1=V, 2=L or 3=R).")
        try:
            pls = int(tp_data.get("pls_code", "0"))
            if not (0 <= pls <= 262143):
                errors.append("PLS Code must be 0-262143.")
        except (ValueError, TypeError):
            errors.append("PLS Code must be an integer.")
        for field, limit, label in (("t2mi_id", 65535, "T2-MI ID"), ("t2mi_pid", 8191, "T2-MI PID"), ("t2mi_plp", 255, "T2-MI PLP")):
            try:
                val = int(tp_data.get(field, "0"))
                if not (0 <= val <= limit):
                    errors.append("{} must be 0-{}.".format(label, limit))
            except (ValueError, TypeError):
                errors.append("{} must be an integer.".format(label))
        return errors
    def _save(self):
        freq_khz = int((self.freq.value[0] + self.freq.value[1] / 10.0) * 1000)
        sr_value = self.symbol_rate.value * 1000
        tp_data = {
            "frequency": str(freq_khz), "symbol_rate": str(sr_value),
            "polarization": self.polarization.value, "fec_inner": self.fec.value,
            "modulation": self.modulation.value, "system": self.system.value,
            "pls_mode": self.pls_mode.value, "pls_code": str(self.pls_code.value),
            "t2mi_id": str(self.t2mi_id.value), "t2mi_pid": str(self.t2mi_pid.value),
            "t2mi_plp": str(self.t2mi_plp.value),
        }
        errors = self._validate(tp_data)
        if errors:
            self.session.open(MessageBox, "Validation errors:\n" + "\n".join(errors), MessageBox.TYPE_ERROR)
            return
        self.close(tp_data)
    def _cancel(self):
        self.close(None)

# ---------------------------------------------------------------------------
# Main screen
# ---------------------------------------------------------------------------
class SatManagerMain(Screen):
    skin = """
    <screen name="SatManagerMain" flags="wfNoBorder" position="center,center"
            size="1280,720" backgroundColor="#1C1C1E" cornerRadius="30">
        <widget name="satListBg"  position="10,60"   size="620,550" backgroundColor="#2C2C2E" cornerRadius="12" zPosition="1" />
        <widget name="tpListBg"   position="650,60"  size="620,550" backgroundColor="#2C2C2C" cornerRadius="12" zPosition="1" />
        <widget name="satTitle"   cornerRadius="12" valign="center" halign="center"
                position="10,10"   size="620,40"  font="Regular;28"
                foregroundColor="#FFFFFF" backgroundColor="#2C2C2E" />
        <widget name="tpTitle"    cornerRadius="12" valign="center" halign="center"
                position="650,10"  size="620,40"  font="Regular;28"
                foregroundColor="#FFFFFF" backgroundColor="#2C2C2E" />
        <widget name="satList"  zPosition="10"  itemHeight="52" transparent="1"
                position="20,70"   size="600,540" backgroundColor="transparent"
                foregroundColor="#FFFFFF" foregroundColorSelected="#CCAACC"
                backgroundColorSelected="#000000" valign="center" font="Regular;36" />
        <widget name="tpList"   zPosition="10"   itemHeight="50" transparent="1"
                position="660,80"  size="600,530" backgroundColor="transparent"
                foregroundColor="#FFFFFF" foregroundColorSelected="#20000000"
                backgroundColorSelected="#CCAACC" valign="center" halign="center" font="Regular;30" />
        
        <widget name="key_red"    cornerRadius="12" position="10,630"   size="210,36"
                backgroundColor="#3A3A3C" foregroundColor="#FF453A"
                valign="center" halign="center" font="Regular;30" zPosition="5" />
        <widget name="key_green"  cornerRadius="12" position="270,630"  size="210,36"
                backgroundColor="#3A3A3C" foregroundColor="#30D158"
                valign="center" halign="center" font="Regular;30" zPosition="5" />
        <widget name="key_yellow" cornerRadius="12" position="530,630"  size="210,36"
                backgroundColor="#3A3A3C" foregroundColor="#FFD60A"
                valign="center" halign="center" font="Regular;30" zPosition="5" />
        <widget name="key_blue"   cornerRadius="12" position="790,630"  size="210,36"
                backgroundColor="#3A3A3C" foregroundColor="#0A84FF"
                valign="center" halign="center" font="Regular;30" zPosition="5" />
        <widget name="menuButton" cornerRadius="12" position="1050,630"  size="210,36"
                backgroundColor="#3A3A3C" foregroundColor="#FFFFFF"
                valign="center" halign="center" font="Regular;30" zPosition="5" />
        <eLabel name="effect" position="5,626" size="1270,46" backgroundColor="#000000" cornerRadius="12" zPosition="1" />
        
        <widget name="status"     position="810,678" size="460,28"
                font="Regular;17" halign="right"
                foregroundColor="#8E8E93" backgroundColor="#1C1C1E" />
        <widget name="statsLabel" position="10,678"  size="700,26"
                font="Regular;16"
                foregroundColor="#8E8E93" backgroundColor="#1C1C1E" />
    </screen>
    """

    _BAND_ICON = {"Ku": "[Ku]", "C": "[C]", "Ka": "[Ka]"}
    _FEC_LABEL = {0: "Auto", 1: "1/2", 2: "2/3", 3: "3/4", 4: "5/6", 5: "7/8", 6: "8/9", 7: "3/5", 8: "4/5", 9: "9/10"}
    _MOD_LABEL = {0: "Auto", 1: "QPSK", 2: "8PSK", 3: "16APSK", 4: "32APSK"}
    _POL_LABEL = {"0": "H", "1": "V", "2": "L", "3": "R"}

    def __init__(self, session):
        Screen.__init__(self, session)
        Screen.setTitle(self, "Satellite Manager")

        self["satList"]    = MenuList([])
        self["tpList"]     = MenuList([])
        self["satTitle"]   = Label("Satellites")
        self["tpTitle"]    = Label("Transponders")
        self["status"]     = Label("")
        self["statsLabel"] = Label("")
        self["menuButton"] = Label("Menu")
        self["key_red"]    = Button("Exit")
        self["key_green"]  = Button("Add Sat")
        self["key_yellow"] = Button("Remove")
        self["key_blue"]   = Button("Edit")
        self["satListBg"]  = Label("")
        self["tpListBg"]   = Label("")

        self.tree             = None
        self.satellites       = []
        self.data_version     = 0
        self.ui_mode          = UIMode.SAT_MODE_NORMAL
        self.selected_indices = set()
        self.current_sat_idx  = -1
        filters = _load_filter_settings()
        self.band_filter      = filters["band"]
        self.direction_filter = filters["direction"]
        self.region_filter    = filters["region"]
        self._busy            = False

        self.tp_current_page = 0
        self.total_tp_pages = 0
        self.sat_current_page = 0
        self.sat_total_pages = 0
        self.sat_page_size = SAT_PAGE_SIZE
        
        self.last_sat_index = -1
        self.last_tp_index = -1
        self.last_tp_page = 0
        self.last_sat_page = 0
        self.last_current_sat_idx = -1
        self.download_source = None

        self._filtered_indices_cache = []
        self._filter_cache_valid = False

        self.deferred_timer = eTimer()
        self.deferred_timer.callback.append(self._execute_deferred)
        self._deferred_func = None

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "NavigationActions", "MenuActions"],
            {
                "ok":     self._ok,
                "cancel": self._cancel,
                "red":    self._red,
                "green":  self._green,
                "yellow": self._yellow,
                "blue":   self._blue,
                "up":     self._up,
                "down":   self._down,
                "left":   self._prev_page,
                "right":  self._next_page,
                "menu":   self._menu,
            },
            -1
        )

        self.onClose.append(self._cleanup_on_exit)
        self.onLayoutFinish.append(self._initialize)

    def _defer(self, func, *args):
        self._deferred_func = lambda: func(*args)
        self.deferred_timer.start(100, True)

    def _execute_deferred(self):
        if self._deferred_func:
            self._deferred_func()
            self._deferred_func = None

    # -----------------------------------------------------------------------
    # Resource cleanup on exit
    # -----------------------------------------------------------------------
    def _cleanup_on_exit(self):
        global _save_in_progress, _save_thread
        
        print("[SatManager] Cleaning up resources on exit...")
        
        if _save_in_progress and _save_thread and _save_thread.is_alive():
            print("[SatManager] Waiting for pending save to complete...")
            _save_thread.join(timeout=SAVE_TIMEOUT)
            if _save_thread.is_alive():
                print("[SatManager] Save operation timed out")
        
        release_file_lock()
        
        self.tree = None
        self.satellites = []
        self._filtered_indices_cache = []
        self._filter_cache_valid = False
        
        try:
            reload_nim_transponders()
            print("[SatManager] Transponders reloaded successfully")
        except Exception as e:
            print("[SatManager] Could not reload transponders: {}".format(e))
        
        print("[SatManager] Cleanup complete")

    # -----------------------------------------------------------------------
    # Initialisation
    # -----------------------------------------------------------------------
    def _ensure_xml_file_exists(self, xml_path):
        """Ensure satellites.xml exists at the specified path.
        If not exists, copy from the other path if available."""
        if os.path.exists(xml_path):
            return True
        
        if xml_path == PATH_ENIGMA2:
            source_path = PATH_TUXBOX
        elif xml_path == PATH_TUXBOX:
            source_path = PATH_ENIGMA2
        else:
            return False
        
        if os.path.exists(source_path):
            self["status"].setText("Copying from {}...".format(source_path))
            if self._copy_xml_file(source_path, xml_path):
                self["status"].setText("Copied from {} to {}".format(source_path, xml_path))
                return True
            else:
                self["status"].setText("Copy failed!")
                return False
        else:
            self["status"].setText("No source file found at {}!".format(source_path))
            return False

    def _copy_xml_file(self, src_path, dst_path):
        if not os.path.exists(src_path):
            return False
        try:
            shutil.copy2(src_path, dst_path)
            os.chmod(dst_path, XML_PERMS)
            print("[SatManager] Copied from {} to {}".format(src_path, dst_path))
            return True
        except Exception as e:
            print("[SatManager] Copy failed: {}".format(e))
            return False

    def _initialize(self):
        global ACTIVE_XML_PATH
        
        self["status"].setText("Checking for satellites.xml...")
        
        filters = _load_filter_settings()
        saved_source = filters.get("xml_source", "auto")
        
        if saved_source == "enigma2":
            ACTIVE_XML_PATH = PATH_ENIGMA2
            self._ensure_xml_file_exists(ACTIVE_XML_PATH)
        elif saved_source == "tuxbox":
            ACTIVE_XML_PATH = PATH_TUXBOX
            self._ensure_xml_file_exists(ACTIVE_XML_PATH)
        else:
            if os.path.exists(PATH_ENIGMA2) and os.access(PATH_ENIGMA2, os.R_OK):
                ACTIVE_XML_PATH = PATH_ENIGMA2
            elif os.path.exists(PATH_TUXBOX) and os.access(PATH_TUXBOX, os.R_OK):
                ACTIVE_XML_PATH = PATH_TUXBOX
            else:
                ACTIVE_XML_PATH = PATH_ENIGMA2
                self._ensure_xml_file_exists(ACTIVE_XML_PATH)
        
        self._async_load()
        self["status"].setText("Using: {}".format(ACTIVE_XML_PATH))

    def _async_load(self):
        self["status"].setText("Loading satellites...")
        def _worker():
            tree, sats = parse_satellites(ACTIVE_XML_PATH)
            _call_main(self._on_load_done, tree, sats)
        t = threading.Thread(target=_worker, daemon=True)
        t.start()

    def _on_load_done(self, tree, sats):
        if tree is not None:
            self.tree = tree
            self.satellites = sats
            self.data_version += 1
        else:
            root = ET.Element("satellites")
            self.tree = ET.ElementTree(root)
            self.satellites = []
        self._invalidate_filter_cache()
        self._refresh_ui()
        source_name = os.path.basename(ACTIVE_XML_PATH) if ACTIVE_XML_PATH else "Unknown"
        self["status"].setText("Loaded {} satellites from {}".format(len(self.satellites), source_name))

    # -----------------------------------------------------------------------
    # Menu handlers
    # -----------------------------------------------------------------------
    def _menu(self):
        if self.ui_mode in (UIMode.SAT_MODE_NORMAL, UIMode.SAT_MODE_MULTI_SELECT):
            self.session.openWithCallback(self._on_main_menu, FilterMenuScreen, "main")

    def _on_main_menu(self, choice):
        if choice == "band":
            self.session.openWithCallback(self._on_band_filter, BandFilterScreen, self.band_filter)
        elif choice == "direction":
            self.session.openWithCallback(self._on_dir_filter, DirectionFilterScreen, self.direction_filter)
        elif choice == "region":
            self.session.openWithCallback(self._on_region_filter, RegionFilterScreen, self.region_filter)
        elif choice == "xml":
            self.session.openWithCallback(self._on_xml_menu, XMLSourceMenuScreen, "select")

    def _on_region_filter(self, result):
        if result is not None:
            self.region_filter = result
            self.current_sat_idx = -1
            self._invalidate_filter_cache()
            self._load_sat_list()
            self._update_stats()
            self["status"].setText("Region filter: {}".format(result))
            _save_filter_settings(self.band_filter, self.direction_filter, self.region_filter)

    def _on_xml_menu(self, choice):
        if choice == "select":
            self.session.openWithCallback(self._on_xml_source_selected, XMLSourceSelectScreen, None)
        elif choice == "info":
            self._show_current_path_info()
        elif choice == "download":
            self.session.openWithCallback(self._on_download_source_selected, DownloadSourceScreen, None)
        elif choice == "restore":
            self._restore_from_backup()

    def _restore_from_backup(self):
        backup_path = os.path.join(BACKUP_DIR, os.path.basename(ACTIVE_XML_PATH) + ".bak")
        
        if not os.path.exists(backup_path):
            self.session.open(MessageBox, "No backup file found!", MessageBox.TYPE_ERROR)
            return
        
        self.session.openWithCallback(
            lambda answer: self._do_restore(answer, backup_path),
            MessageBox,
            "Restore satellites.xml from backup?\n\nThis will overwrite the current file.",
            MessageBox.TYPE_YESNO
        )

    def _do_restore(self, answer, backup_path):
        if not answer:
            return
        
        try:
            shutil.copy2(backup_path, ACTIVE_XML_PATH)
            os.chmod(ACTIVE_XML_PATH, XML_PERMS)
            self._async_load()
            self["status"].setText("Restored from backup")
            show_restart_warning(self.session, "restored a")
        except Exception as e:
            self.session.open(MessageBox, "Failed to restore backup:\n{}".format(str(e)), MessageBox.TYPE_ERROR)

    def _on_download_source_selected(self, source):
        if source:
            self.download_source = source
            self.session.openWithCallback(self._on_download_destination_selected, DownloadDestinationScreen, None, source)
        else:
            self["status"].setText("Download cancelled")

    def _on_download_destination_selected(self, destination):
        if destination and hasattr(self, 'download_source') and self.download_source:
            source = self.download_source
            url = DOWNLOAD_SOURCES.get(source)
            if url:
                dest_path = PATH_ENIGMA2 if destination == "enigma2" else PATH_TUXBOX
                self._download_and_save_xml(url, dest_path)
            else:
                self.session.open(MessageBox, "Invalid download source!", MessageBox.TYPE_ERROR)
        else:
            self["status"].setText("Download cancelled")

    def _download_and_save_xml(self, url, dest_path):
        source_name = url.split('/')[-2] if '/raw/main/' in url else url.split('/')[2]
        self["status"].setText("Downloading from {}...".format(source_name))
        
        def _worker():
            try:
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
                response = requests.get(url, timeout=30, verify=False, headers=headers)
                response.raise_for_status()
                content = response.text
                
                try:
                    root = ET.fromstring(content)
                    tree = ET.ElementTree(root)
                    save_safely(tree, dest_path)
                    _call_main(self._on_download_success, dest_path)
                except ET.ParseError as e:
                    import re
                    xml_match = re.search(r'<\?xml.*?</satellites>', content, re.DOTALL)
                    if xml_match:
                        content = xml_match.group(0)
                        root = ET.fromstring(content)
                        tree = ET.ElementTree(root)
                        save_safely(tree, dest_path)
                        _call_main(self._on_download_success, dest_path)
                    else:
                        _call_main(self._on_download_error, "Invalid XML format: {}".format(str(e)))
            except requests.exceptions.SSLError as e:
                print("[SatManager] SSL Error, retrying with session...")
                try:
                    session = requests.Session()
                    session.verify = False
                    response = session.get(url, timeout=30, headers=headers)
                    response.raise_for_status()
                    content = response.text
                    root = ET.fromstring(content)
                    tree = ET.ElementTree(root)
                    save_safely(tree, dest_path)
                    _call_main(self._on_download_success, dest_path)
                except Exception as e2:
                    _call_main(self._on_download_error, "SSL Error: {}".format(str(e2)))
            except requests.exceptions.RequestException as e:
                _call_main(self._on_download_error, "Download failed: {}".format(str(e)))
            except Exception as e:
                _call_main(self._on_download_error, "Error: {}".format(str(e)))
        
        t = threading.Thread(target=_worker, daemon=True)
        t.start()

    def _on_download_success(self, dest_path):
        global ACTIVE_XML_PATH
        ACTIVE_XML_PATH = dest_path
        self._save_current_xml_source("enigma2" if dest_path == PATH_ENIGMA2 else "tuxbox")
        self._async_load()
        self["status"].setText("Downloaded and saved to {}".format(dest_path))
        show_restart_warning(self.session, "downloaded a new")

    def _on_download_error(self, error_msg):
        self.session.open(MessageBox, "Download failed!\n{}".format(error_msg), MessageBox.TYPE_ERROR)
        self["status"].setText("Download failed")

    def _on_xml_source_selected(self, choice):
        global ACTIVE_XML_PATH
        
        if choice is None:
            return
        
        new_path = None
        if choice == "enigma2":
            new_path = PATH_ENIGMA2
        elif choice == "tuxbox":
            new_path = PATH_TUXBOX
        else:
            return
        
        if not self._ensure_xml_file_exists(new_path):
            self.session.open(MessageBox, 
                "Cannot access satellites.xml at {}!\nPlease check file permissions.".format(new_path),
                MessageBox.TYPE_ERROR)
            return
        
        ACTIVE_XML_PATH = new_path
        self._save_current_xml_source(choice)
        self._async_load()
        self["status"].setText("Switched to {}".format(ACTIVE_XML_PATH))
        self._refresh_ui()

    def _save_current_xml_source(self, source):
        filters = _load_filter_settings()
        _save_filter_settings(filters["band"], filters["direction"], filters["region"], source)

    def _show_current_path_info(self):
        global ACTIVE_XML_PATH
        
        if not ACTIVE_XML_PATH:
            info = "No active path selected!"
        else:
            exists = os.path.exists(ACTIVE_XML_PATH)
            readable = os.access(ACTIVE_XML_PATH, os.R_OK) if exists else False
            writable = os.access(os.path.dirname(ACTIVE_XML_PATH), os.W_OK) if exists else False
            total_tps = sum(len(sat.findall("transponder")) for sat in self.satellites)
            
            info_lines = []
            info_lines.append("=" * 50)
            info_lines.append("CURRENT XML FILE")
            info_lines.append("=" * 50)
            info_lines.append("")
            info_lines.append("Path: {}".format(ACTIVE_XML_PATH))
            info_lines.append("")
            info_lines.append("-" * 50)
            info_lines.append("STATUS")
            info_lines.append("-" * 50)
            info_lines.append("")
            info_lines.append("  File exists:  {}".format("Yes" if exists else "No"))
            info_lines.append("  Readable:     {}".format("Yes" if readable else "No"))
            info_lines.append("  Writable:     {}".format("Yes" if writable else "No"))
            info_lines.append("")
            info_lines.append("-" * 50)
            info_lines.append("STATISTICS")
            info_lines.append("-" * 50)
            info_lines.append("")
            info_lines.append("  Satellites:    {}".format(len(self.satellites)))
            info_lines.append("  Transponders:  {}".format(total_tps))
            info_lines.append("")
            info_lines.append("-" * 50)
            info_lines.append("TIPS")
            info_lines.append("-" * 50)
            info_lines.append("")
            info_lines.append("  Use 'Select' to change source")
            info_lines.append("  Use 'Download' to get latest from internet")
            info_lines.append("  Use 'Restore' to recover from backup")
            info_lines.append("")
            info_lines.append("=" * 50)
            
            info = "\n".join(info_lines)
        
        self.session.open(XMLPathInfoScreen, info)

    # -----------------------------------------------------------------------
    # Cache management
    # -----------------------------------------------------------------------
    def _invalidate_filter_cache(self):
        self._filter_cache_valid = False

    def _get_filtered_indices(self):
        if self._filter_cache_valid:
            return self._filtered_indices_cache
        result = []
        for i, sat in enumerate(self.satellites):
            if self.band_filter != "All":
                if get_band_type_from_sat(sat) != self.band_filter:
                    continue
            if self.direction_filter != "All":
                try:
                    pos = int(sat.get("position", "0"))
                except (ValueError, TypeError):
                    pos = 0
                if self.direction_filter == "East" and pos < 0:
                    continue
                if self.direction_filter == "West" and pos >= 0:
                    continue
            if self.region_filter != "All":
                try:
                    pos = int(sat.get("position", "0"))
                    region = get_geographic_region(pos)
                    if region != self.region_filter:
                        continue
                except (ValueError, TypeError):
                    continue
            result.append(i)
        self._filtered_indices_cache = result
        self._filter_cache_valid = True
        return result

    # -----------------------------------------------------------------------
    # Save + reload
    # -----------------------------------------------------------------------
    def _async_save_and_reload(self, is_satellite_change=False):
        global _save_in_progress, _save_thread, ACTIVE_XML_PATH
        
        if self._busy or not self.tree:
            return
        
        if _save_in_progress and _save_thread and _save_thread.is_alive():
            self["status"].setText("Save already in progress...")
            return
        
        self._busy = True
        _save_in_progress = True
        self["status"].setText("Saving...")
        
        try:
            xml_bytes = _build_pretty_xml(self.tree.getroot())
        except Exception as exc:
            self._busy = False
            _save_in_progress = False
            self.session.open(MessageBox, "Serialisation error:\n{}".format(exc), MessageBox.TYPE_ERROR)
            return
        
        def _worker():
            global _save_in_progress
            try:
                directory = os.path.dirname(ACTIVE_XML_PATH) or "."
                if not os.access(directory, os.W_OK):
                    raise OSError("No write permission on directory")
                
                with _file_lock:
                    fd, tmp_path = tempfile.mkstemp(dir=directory, suffix=".xml.tmp")
                    try:
                        with os.fdopen(fd, "wb") as fh:
                            fh.write(xml_bytes)
                            fh.flush()
                            os.fsync(fh.fileno())
                    except:
                        os.close(fd)
                        raise
                    
                    if os.path.exists(ACTIVE_XML_PATH):
                        _rotate_backups(ACTIVE_XML_PATH)
                    shutil.move(tmp_path, ACTIVE_XML_PATH)
                    tmp_path = None
                    os.chmod(ACTIVE_XML_PATH, XML_PERMS)
                
                new_tree, new_sats = parse_satellites(ACTIVE_XML_PATH)
                _call_main(self._on_save_done, True, new_tree, new_sats, is_satellite_change)
            except Exception as exc:
                print("[SatManager] Save error: {}".format(exc))
                _call_main(self._on_save_done, False, None, None, False)
            finally:
                _save_in_progress = False
        
        _save_thread = threading.Thread(target=_worker, daemon=True)
        _save_thread.start()

    def _on_save_done(self, success, new_tree, new_sats, is_satellite_change=False):
        self._busy = False
        if success and new_tree is not None:
            self.tree = new_tree
            self.satellites = new_sats
            self.data_version += 1
            
            reload_nim_transponders()
                
            self._invalidate_filter_cache()
            self._refresh_ui()
            
            if is_satellite_change:
                show_restart_warning(self.session, "added or deleted")
            
            self["status"].setText("Saved successfully to {}".format(os.path.basename(ACTIVE_XML_PATH)))
        else:
            self.session.open(MessageBox, "Failed to save changes.\nCheck file permissions.", MessageBox.TYPE_ERROR)

    # -----------------------------------------------------------------------
    # UI refresh with cursor position preservation
    # -----------------------------------------------------------------------
    def _refresh_ui(self):
        if self.ui_mode in (UIMode.SAT_MODE_NORMAL, UIMode.SAT_MODE_MULTI_SELECT):
            if self["satList"].list and self["satList"].getCurrentIndex() >= 0:
                self.last_sat_index = self["satList"].getCurrentIndex()
            self.last_sat_page = self.sat_current_page
        
        if self.ui_mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            if self["tpList"].list and self["tpList"].getCurrentIndex() >= 0:
                self.last_tp_index = self["tpList"].getCurrentIndex()
            self.last_tp_page = self.tp_current_page
            self.last_current_sat_idx = self.current_sat_idx
        
        self._load_sat_list()
        self._update_stats()
        self._update_buttons()
        
        if self.ui_mode in (UIMode.SAT_MODE_NORMAL, UIMode.SAT_MODE_MULTI_SELECT):
            if self.last_sat_index >= 0 and self["satList"].list and self.last_sat_index < len(self["satList"].list):
                self["satList"].moveToIndex(self.last_sat_index)
            self.sat_current_page = self.last_sat_page
            self._load_sat_list()
        
        if self.ui_mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            if self.last_current_sat_idx >= 0 and self.last_current_sat_idx < len(self.satellites):
                self.current_sat_idx = self.last_current_sat_idx
                self.tp_current_page = self.last_tp_page
                self._load_tp_list()
                if self.last_tp_index >= 0 and self["tpList"].list and self.last_tp_index < len(self["tpList"].list):
                    self["tpList"].moveToIndex(self.last_tp_index)
        
        if 0 <= self.current_sat_idx < len(self.satellites):
            self.tp_current_page = 0
            self._load_tp_list()
        else:
            self.current_sat_idx = -1
            self["tpList"].setList([])
            self["tpTitle"].setText("Transponders")

    def _load_sat_list(self):
        filtered = self._get_filtered_indices()
        total_filtered = len(filtered)
        self.sat_total_pages = (total_filtered + self.sat_page_size - 1) // self.sat_page_size if total_filtered > 0 else 1
        if self.sat_current_page >= self.sat_total_pages:
            self.sat_current_page = max(0, self.sat_total_pages - 1)
        start = self.sat_current_page * self.sat_page_size
        end = min(start + self.sat_page_size, total_filtered)
        page_indices = filtered[start:end]
    
        items = []
        for display_idx, real_idx in enumerate(page_indices):
            sat = self.satellites[real_idx]
            name = sat.get("name", "Unknown")
            try:
                pos = int(sat.get("position", "0"))
            except (ValueError, TypeError):
                pos = 0
            pos_str = format_position(pos)
    
            is_selected = (real_idx == self.current_sat_idx)
            if self.ui_mode == UIMode.SAT_MODE_MULTI_SELECT:
                mark = "[X] " if real_idx in self.selected_indices else "[ ] "
            else:
                mark = "> " if is_selected else "  "
    
            text = "{}{} | {}".format(mark, name, pos_str)
            items.append((text, real_idx))
    
        self["satList"].setList(items)
        page_info = " (Page {}/{})".format(self.sat_current_page+1, self.sat_total_pages) if self.sat_total_pages > 1 else ""
        
        source_info = ""
        if ACTIVE_XML_PATH:
            if "enigma2" in ACTIVE_XML_PATH:
                source_info = " [Source: Enigma2/satellites.xml]"
            elif "tuxbox" in ACTIVE_XML_PATH:
                source_info = " [Source: tuxbox/satellites.xml]"
        else:
            source_info = " [Source: Unknown]"
        
        self["satTitle"].setText("Satellites ({}){}".format(len(items), page_info))
    
        if items:
            if self.current_sat_idx >= 0:
                try:
                    new_disp = page_indices.index(self.current_sat_idx)
                    self["satList"].moveToIndex(new_disp)
                except ValueError:
                    if page_indices:
                        self.current_sat_idx = page_indices[0]
                        self["satList"].moveToIndex(0)
                    else:
                        self.current_sat_idx = -1
            else:
                if self["satList"].getCurrentIndex() < 0 and items:
                    self["satList"].moveToIndex(0)

    def _load_tp_list(self):
        if not (0 <= self.current_sat_idx < len(self.satellites)):
            self["tpList"].setList([])
            return
        sat = self.satellites[self.current_sat_idx]
        sat_name = sat.get("name", "Unknown")
        all_tps = sat.findall("transponder")
        total_tps = len(all_tps)
        self.total_tp_pages = (total_tps + TP_PAGE_SIZE - 1) // TP_PAGE_SIZE if total_tps > 0 else 1
        if self.tp_current_page >= self.total_tp_pages:
            self.tp_current_page = max(0, self.total_tp_pages - 1)
        start = self.tp_current_page * TP_PAGE_SIZE
        end = min(start + TP_PAGE_SIZE, total_tps)
        page_tps = all_tps[start:end]

        items = []
        for i, tp in enumerate(page_tps):
            real_idx = start + i
            band_type = get_band_type(int(tp.get("frequency", "0")))
            freq = format_frequency_khz(tp.get("frequency", "0"), band_type=band_type)
            pol = self._POL_LABEL.get(tp.get("polarization"), "?")
            try:
                sr = str(int(tp.get("symbol_rate", "0")) // 1000)
            except (ValueError, TypeError):
                sr = "0"
            try:
                fec_key = int(tp.get("fec_inner", "0"))
            except (ValueError, TypeError):
                fec_key = 0
            try:
                mod_key = int(tp.get("modulation", "0"))
            except (ValueError, TypeError):
                mod_key = 0
            fec = self._FEC_LABEL.get(fec_key, "Auto")
            mod = self._MOD_LABEL.get(mod_key, "Auto")
            system = "S2" if tp.get("system") == "1" else "S"
            band_icon = self._BAND_ICON.get(band_type, "")
            extras = []
            if tp.get("pls_code", "0") != "0" or tp.get("pls_mode", "0") != "0":
                extras.append("[PLS]")
            if tp.get("t2mi_id", "0") != "0":
                extras.append("[T2-MI]")
            extra_str = " " + " ".join(extras) if extras else ""
            mark = "[X] " if real_idx in self.selected_indices else "[ ] " if self.ui_mode == UIMode.TP_MODE_MULTI_SELECT else "   "
            items.append(("{}{} {} {} {} | {} {} {}{}".format(mark, band_icon, freq, pol, sr, fec, mod, system, extra_str), real_idx))

        self["tpList"].setList(items)
        page_info = " (Page {}/{})".format(self.tp_current_page+1, self.total_tp_pages) if self.total_tp_pages > 1 else ""
        self["tpTitle"].setText("{} ({} TPs){} <-/->".format(sat_name, total_tps, page_info))
        if self.total_tp_pages > 1:
            self["status"].setText("Page {} of {} - use Left/Right arrows (wraps)".format(self.tp_current_page+1, self.total_tp_pages))
        else:
            self["status"].setText("")

    def _update_stats(self):
        total_sats = len(self.satellites)
        total_tps = sum(len(sat.findall("transponder")) for sat in self.satellites)
        shown = len(self._get_filtered_indices())
        filters = []
        if self.band_filter != "All":
            filters.append("Band:{}".format(self.band_filter))
        if self.direction_filter != "All":
            filters.append("Dir:{}".format(self.direction_filter))
        if self.region_filter != "All":
            filters.append("Region:{}".format(self.region_filter))
        filter_text = " | ".join(filters) if filters else "No filter"
        
        if ACTIVE_XML_PATH:
            if "enigma2" in ACTIVE_XML_PATH:
                source_text = "Using: /etc/enigma2/satellites.xml"
            elif "tuxbox" in ACTIVE_XML_PATH:
                source_text = "Using: /etc/tuxbox/satellites.xml"
            else:
                source_text = "Using: {}".format(ACTIVE_XML_PATH)
        else:
            source_text = "Using: Unknown source"
        
        self["statsLabel"].setText("{} | {} | Total: {} Sats | {} TPs | Shown: {}".format(source_text, filter_text, total_sats, total_tps, shown))

    def _update_buttons(self):
        mode = self.ui_mode
        if mode == UIMode.TP_MODE_NORMAL:
            self["key_red"].setText("<- Back")
            self["key_green"].setText("Add TP")
            self["key_yellow"].setText("Remove")
            self["key_blue"].setText("Delete")
        elif mode == UIMode.TP_MODE_MULTI_SELECT:
            self["key_red"].setText("<- Back")
            self["key_green"].setText("Select All")
            self["key_yellow"].setText("Done")
            self["key_blue"].setText("Delete")
        elif mode == UIMode.SAT_MODE_NORMAL:
            self["key_red"].setText("Exit")
            self["key_green"].setText("Add Sat")
            self["key_yellow"].setText("Remove")
            self["key_blue"].setText("Edit")
        elif mode == UIMode.SAT_MODE_MULTI_SELECT:
            self["key_red"].setText("Exit")
            self["key_green"].setText("Select All")
            self["key_yellow"].setText("Confirm")
            self["key_blue"].setText("Cancel")

    # -----------------------------------------------------------------------
    # Navigation with wrap-around
    # -----------------------------------------------------------------------
    def _prev_page(self):
        if self.ui_mode in (UIMode.SAT_MODE_NORMAL, UIMode.SAT_MODE_MULTI_SELECT):
            if self.sat_total_pages > 1:
                if self.sat_current_page > 0:
                    self.sat_current_page -= 1
                else:
                    self.sat_current_page = self.sat_total_pages - 1
                self._load_sat_list()
                self["status"].setText("Satellites: page {} of {}".format(self.sat_current_page+1, self.sat_total_pages))
        else:
            if self.total_tp_pages > 1:
                if self.tp_current_page > 0:
                    self.tp_current_page -= 1
                else:
                    self.tp_current_page = self.total_tp_pages - 1
                self._load_tp_list()
                self["status"].setText("Transponders: page {} of {}".format(self.tp_current_page+1, self.total_tp_pages))

    def _next_page(self):
        if self.ui_mode in (UIMode.SAT_MODE_NORMAL, UIMode.SAT_MODE_MULTI_SELECT):
            if self.sat_total_pages > 1:
                if self.sat_current_page < self.sat_total_pages - 1:
                    self.sat_current_page += 1
                else:
                    self.sat_current_page = 0
                self._load_sat_list()
                self["status"].setText("Satellites: page {} of {}".format(self.sat_current_page+1, self.sat_total_pages))
        else:
            if self.total_tp_pages > 1:
                if self.tp_current_page < self.total_tp_pages - 1:
                    self.tp_current_page += 1
                else:
                    self.tp_current_page = 0
                self._load_tp_list()
                self["status"].setText("Transponders: page {} of {}".format(self.tp_current_page+1, self.total_tp_pages))

    def _up(self):
        lst = "tpList" if self.ui_mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT) else "satList"
        if self[lst].list and self[lst].getCurrentIndex() > 0:
            self[lst].up()

    def _down(self):
        lst = "tpList" if self.ui_mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT) else "satList"
        items = self[lst].list or []
        if items and self[lst].getCurrentIndex() < len(items) - 1:
            self[lst].down()

    # -----------------------------------------------------------------------
    # Multi-select - Select All
    # -----------------------------------------------------------------------
    def _select_all_satellites(self):
        """Select all satellites in the current page/filter"""
        filtered = self._get_filtered_indices()
        start = self.sat_current_page * self.sat_page_size
        end = min(start + self.sat_page_size, len(filtered))
        page_indices = filtered[start:end]
        
        for real_idx in page_indices:
            self.selected_indices.add(real_idx)
        self._load_sat_list()
        self["status"].setText("Selected {} satellites".format(len(self.selected_indices)))

    def _select_all_transponders(self):
        """Select all transponders in the current page"""
        if self.current_sat_idx < 0:
            return
        sat = self.satellites[self.current_sat_idx]
        all_tps = sat.findall("transponder")
        total = len(all_tps)
        start = self.tp_current_page * TP_PAGE_SIZE
        end = min(start + TP_PAGE_SIZE, total)
        
        for idx in range(start, end):
            self.selected_indices.add(idx)
        self._load_tp_list()
        self["status"].setText("Selected {} transponders".format(len(self.selected_indices)))

    def _switch_to_tp_list(self):
        self.ui_mode = UIMode.TP_MODE_NORMAL
        self.selected_indices.clear()
        self.tp_current_page = 0
        self["satList"].instance.setSelectionEnable(False)
        self["tpList"].instance.setSelectionEnable(True)
        self._load_tp_list()
        self._update_buttons()
        if self["tpList"].list:
            self["tpList"].moveToIndex(0)
        self["status"].setText("Transponder list active - Red to go back")

    def _switch_to_sat_list(self):
        self.ui_mode = UIMode.SAT_MODE_NORMAL
        self.selected_indices.clear()
        self["tpList"].instance.setSelectionEnable(False)
        self["satList"].instance.setSelectionEnable(True)
        self._load_sat_list()
        self._update_buttons()
        if self.last_sat_index >= 0 and self["satList"].list and self.last_sat_index < len(self["satList"].list):
            self["satList"].moveToIndex(self.last_sat_index)
            filtered = self._get_filtered_indices()
            if self.last_sat_index < len(filtered):
                self.current_sat_idx = filtered[self.last_sat_index]
        self["status"].setText("Satellite list active - OK to view transponders")

    # -----------------------------------------------------------------------
    # Multi-select
    # -----------------------------------------------------------------------
    def _enable_sat_multiselect(self):
        self.ui_mode = UIMode.SAT_MODE_MULTI_SELECT
        self.selected_indices.clear()
        self._load_sat_list()
        self._update_buttons()
        self["status"].setText("Select satellites - OK to mark, Green for Select All, Yellow to confirm")

    def _disable_sat_multiselect(self):
        self.ui_mode = UIMode.SAT_MODE_NORMAL
        self.selected_indices.clear()
        self._load_sat_list()
        self._update_buttons()
        self["status"].setText("Selection cancelled")

    def _enable_tp_multiselect(self):
        self.ui_mode = UIMode.TP_MODE_MULTI_SELECT
        self.selected_indices.clear()
        self._load_tp_list()
        self._update_buttons()
        self["status"].setText("Select transponders - OK to mark, Green for Select All, Yellow to delete")

    def _disable_tp_multiselect(self):
        self.ui_mode = UIMode.TP_MODE_NORMAL
        self.selected_indices.clear()
        self._load_tp_list()
        self._update_buttons()
        self["status"].setText("Selection cancelled")

    def _toggle_sat_selection(self):
        cur = self["satList"].getCurrent()
        if not cur:
            return
        real_idx = cur[1]
        if real_idx in self.selected_indices:
            self.selected_indices.discard(real_idx)
        else:
            self.selected_indices.add(real_idx)
        disp_idx = self["satList"].getCurrentIndex()
        self._load_sat_list()
        self["satList"].moveToIndex(disp_idx)
        self["status"].setText("{} satellites selected".format(len(self.selected_indices)))

    def _toggle_tp_selection(self):
        cur = self["tpList"].getCurrent()
        if not cur:
            return
        real_idx = cur[1]
        disp_idx = self["tpList"].getCurrentIndex()
        if real_idx in self.selected_indices:
            self.selected_indices.discard(real_idx)
        else:
            self.selected_indices.add(real_idx)
        self._load_tp_list()
        self["tpList"].moveToIndex(disp_idx)
        self["status"].setText("{} transponders selected".format(len(self.selected_indices)))

    # -----------------------------------------------------------------------
    # Satellite CRUD
    # -----------------------------------------------------------------------
    def _add_satellite(self):
        existing = [s.get("name", "") for s in self.satellites if s.get("name")]
        self.session.openWithCallback(self._on_add_sat, AddSatelliteScreen, existing)

    def _on_add_sat(self, result):
        if result is None:
            return
        name, position, band_type = result
        sat = ET.Element("sat", {"name": name, "position": str(position), "flags": "1", "band": band_type})
        _cache_band_for_satellite(sat)
        self.tree.getroot().append(sat)
        self._async_save_and_reload(is_satellite_change=True)
        self._defer(self._select_new_satellite, name)
        self["status"].setText("Satellite added: {}".format(name))

    def _select_new_satellite(self, sat_name):
        for idx, sat in enumerate(self.satellites):
            if sat.get("name", "") == sat_name:
                self.current_sat_idx = idx
                self.last_current_sat_idx = idx
                self._switch_to_tp_list()
                break
        self._refresh_ui()

    def _edit_satellite(self):
        if self.ui_mode == UIMode.SAT_MODE_MULTI_SELECT:
            self._disable_sat_multiselect()
            return
        cur = self["satList"].getCurrent()
        if not cur:
            return
        real_idx = cur[1]
        if not (0 <= real_idx < len(self.satellites)):
            return
        sat = self.satellites[real_idx]
        name = sat.get("name", "")
        try:
            pos = int(sat.get("position", "130"))
        except (ValueError, TypeError):
            pos = 130
        deg = abs(pos) / 10.0
        direction = "E" if pos >= 0 else "W"
        current_band = sat.get("band", get_band_type_from_sat(sat))
        self.session.openWithCallback(lambda res: self._on_edit_sat(res, real_idx), 
                                      SatelliteEditScreen, name, deg, direction, current_band)

    def _on_edit_sat(self, result, real_idx):
        if result is None or not (0 <= real_idx < len(self.satellites)):
            return
        new_name, new_deg, new_dir, new_band = result
        new_pos = int(new_deg * 10)
        if new_dir == "W":
            new_pos = -new_pos
        
        current_sat_index = self["satList"].getCurrentIndex() if self["satList"].list else -1
        
        self.satellites[real_idx].set("name", new_name)
        self.satellites[real_idx].set("position", str(new_pos))
        self.satellites[real_idx].set("band", new_band)
        self.satellites[real_idx].set("_cached_band", None)
        _cache_band_for_satellite(self.satellites[real_idx])
        self._invalidate_filter_cache()
        self._async_save_and_reload(is_satellite_change=False)
        self._defer(self._restore_sat_position, current_sat_index)
        self["status"].setText("Satellite updated")

    def _restore_sat_position(self, sat_index):
        self._refresh_ui()
        if sat_index >= 0 and self["satList"].list and sat_index < len(self["satList"].list):
            self["satList"].moveToIndex(sat_index)
            if self.ui_mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
                filtered = self._get_filtered_indices()
                if sat_index < len(filtered):
                    self.current_sat_idx = filtered[sat_index]
                    self._load_tp_list()

    def _delete_selected_sats(self):
        if not self.tree or not self.selected_indices:
            return
        names = [self.satellites[i].get("name", "Unknown") for i in sorted(self.selected_indices) if i < len(self.satellites)]
        if not names:
            return
        shown = names[:MAX_DELETE_NAMES_SHOWN]
        extra = len(names) - len(shown)
        body = "\n".join(shown)
        if extra > 0:
            body += "\n... and {} more".format(extra)
        self.session.openWithCallback(self._on_delete_sats, MessageBox, "Delete {} satellites?\n\n{}".format(len(names), body), MessageBox.TYPE_YESNO)

    def _on_delete_sats(self, yes):
        if not yes or not self.tree:
            return
        root = self.tree.getroot()
        
        current_sat_index = self.current_sat_idx
        
        for idx in sorted(self.selected_indices, reverse=True):
            if idx < len(self.satellites):
                root.remove(self.satellites[idx])
        
        if current_sat_index in self.selected_indices:
            remaining = [i for i in range(len(self.satellites)) if i not in self.selected_indices]
            if remaining:
                new_index = remaining[0] if current_sat_index > remaining[-1] else remaining[-1]
                self.current_sat_idx = new_index
            else:
                self.current_sat_idx = -1
        else:
            offset = sum(1 for idx in self.selected_indices if idx < current_sat_index)
            self.current_sat_idx = current_sat_index - offset
        
        self.selected_indices.clear()
        self.ui_mode = UIMode.SAT_MODE_NORMAL
        self._invalidate_filter_cache()
        self._async_save_and_reload(is_satellite_change=True)
        self._defer(self._restore_sat_after_delete)
        self["status"].setText("Satellites deleted")

    def _restore_sat_after_delete(self):
        self._refresh_ui()
        if self.current_sat_idx >= 0 and self["satList"].list and self.current_sat_idx < len(self["satList"].list):
            self["satList"].moveToIndex(self.current_sat_idx)

    # -----------------------------------------------------------------------
    # Transponder CRUD
    # -----------------------------------------------------------------------
    def _show_transponders(self):
        cur = self["satList"].getCurrent()
        if not cur:
            return
        self.current_sat_idx = cur[1]
        self.last_current_sat_idx = self.current_sat_idx
        self.last_sat_index = self["satList"].getCurrentIndex()
        self._load_sat_list()
        self._switch_to_tp_list()

    def _add_transponder(self):
        if self.current_sat_idx < 0:
            self.session.open(MessageBox, "Select a satellite first.", MessageBox.TYPE_INFO)
            return
        sat = self.satellites[self.current_sat_idx]
        sat_band = sat.get("band", get_band_type_from_sat(sat))
        self.session.openWithCallback(self._on_add_tp, TransponderEditScreen, None, True, sat_band)

    def _on_add_tp(self, tp_data):
        if not tp_data or not (0 <= self.current_sat_idx < len(self.satellites)):
            return
        try:
            sat = self.satellites[self.current_sat_idx]
            tp = ET.Element("transponder", tp_data)
            sat.append(tp)
            sat.set("_cached_band", None)
            _cache_band_for_satellite(sat)
            
            current_tp_index = self["tpList"].getCurrentIndex() if self["tpList"].list else -1
            current_tp_page = self.tp_current_page
            
            self._invalidate_filter_cache()
            self._async_save_and_reload(is_satellite_change=False)
            self._defer(self._restore_tp_position, current_tp_index, current_tp_page)
            self["status"].setText("Transponder added")
        except Exception as exc:
            self.session.open(MessageBox, "Error adding transponder:\n{}".format(exc), MessageBox.TYPE_ERROR)

    def _edit_transponder(self):
        if self.ui_mode == UIMode.TP_MODE_MULTI_SELECT:
            self._toggle_tp_selection()
            return
        cur = self["tpList"].getCurrent()
        if not cur or self.current_sat_idx < 0:
            return
        real_idx = cur[1]
        sat = self.satellites[self.current_sat_idx]
        tps = sat.findall("transponder")
        if not (0 <= real_idx < len(tps)):
            return
        sat_band = sat.get("band", get_band_type_from_sat(sat))
        self.session.openWithCallback(lambda res: self._on_edit_tp(res, real_idx), 
                                      TransponderEditScreen, tps[real_idx], False, sat_band)

    def _on_edit_tp(self, tp_data, tp_idx):
        if not tp_data or not (0 <= self.current_sat_idx < len(self.satellites)):
            return
        sat = self.satellites[self.current_sat_idx]
        tps = sat.findall("transponder")
        if not (0 <= tp_idx < len(tps)):
            return
        
        current_tp_index = self["tpList"].getCurrentIndex() if self["tpList"].list else -1
        current_tp_page = self.tp_current_page
        
        for key, value in tp_data.items():
            tps[tp_idx].set(key, value)
        sat.set("_cached_band", None)
        _cache_band_for_satellite(sat)
        self._invalidate_filter_cache()
        self._async_save_and_reload(is_satellite_change=False)
        self._defer(self._restore_tp_position, current_tp_index, current_tp_page)
        self["status"].setText("Transponder updated")

    def _delete_selected_tps(self):
        if not self.selected_indices or self.current_sat_idx < 0:
            return
        count = len(self.selected_indices)
        self.session.openWithCallback(self._on_delete_tps, MessageBox, "Delete {} transponder{}?".format(count, "s" if count > 1 else ""), MessageBox.TYPE_YESNO)

    def _on_delete_tps(self, yes):
        if not yes or not (0 <= self.current_sat_idx < len(self.satellites)):
            return
        sat = self.satellites[self.current_sat_idx]
        tps = sat.findall("transponder")
        
        current_tp_index = self["tpList"].getCurrentIndex() if self["tpList"].list else -1
        
        for tp_idx in sorted(self.selected_indices, reverse=True):
            if tp_idx < len(tps):
                sat.remove(tps[tp_idx])
        sat.set("_cached_band", None)
        _cache_band_for_satellite(sat)
        self._invalidate_filter_cache()
        self.selected_indices.clear()
        self.ui_mode = UIMode.TP_MODE_NORMAL
        self._async_save_and_reload(is_satellite_change=False)
        self._defer(self._restore_tp_after_delete, current_tp_index)
        self["status"].setText("Transponders deleted")

    def _restore_tp_after_delete(self, old_index):
        self._load_tp_list()
        new_index = min(old_index, len(self["tpList"].list) - 1) if self["tpList"].list else -1
        if new_index >= 0:
            self["tpList"].moveToIndex(new_index)
        self._refresh_ui()

    def _restore_tp_position(self, tp_index, tp_page):
        self.tp_current_page = tp_page
        self._load_tp_list()
        if tp_index >= 0 and self["tpList"].list and tp_index < len(self["tpList"].list):
            self["tpList"].moveToIndex(tp_index)
        self._refresh_ui()

    # -----------------------------------------------------------------------
    # Filter callbacks
    # -----------------------------------------------------------------------
    def _on_band_filter(self, result):
        if result is not None:
            self.band_filter = result
            self.current_sat_idx = -1
            self._invalidate_filter_cache()
            self._load_sat_list()
            self._update_stats()
            self["status"].setText("Band filter: {}".format(result))
            _save_filter_settings(self.band_filter, self.direction_filter, self.region_filter)

    def _on_dir_filter(self, result):
        if result is not None:
            self.direction_filter = result
            self.current_sat_idx = -1
            self._invalidate_filter_cache()
            self._load_sat_list()
            self._update_stats()
            self["status"].setText("Direction filter: {}".format(result))
            _save_filter_settings(self.band_filter, self.direction_filter, self.region_filter)

    # -----------------------------------------------------------------------
    # Key handlers
    # -----------------------------------------------------------------------
    def _ok(self):
        mode = self.ui_mode
        if mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            if mode == UIMode.TP_MODE_MULTI_SELECT:
                self._toggle_tp_selection()
            else:
                self._edit_transponder()
        else:
            if mode == UIMode.SAT_MODE_MULTI_SELECT:
                self._toggle_sat_selection()
            else:
                self._show_transponders()

    def _cancel(self):
        mode = self.ui_mode
        if mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            self._switch_to_sat_list()
        elif mode == UIMode.SAT_MODE_MULTI_SELECT:
            self._disable_sat_multiselect()
        else:
            self.close()

    def _red(self):
        mode = self.ui_mode
        if mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            self._switch_to_sat_list()
        elif mode == UIMode.SAT_MODE_MULTI_SELECT:
            self._disable_sat_multiselect()
        else:
            self.close()

    def _green(self):
        mode = self.ui_mode
        if mode == UIMode.TP_MODE_MULTI_SELECT:
            self._select_all_transponders()
        elif mode == UIMode.SAT_MODE_MULTI_SELECT:
            self._select_all_satellites()
        elif self.ui_mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            self._add_transponder()
        else:
            self._add_satellite()

    def _yellow(self):
        mode = self.ui_mode
        if mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            if mode == UIMode.TP_MODE_MULTI_SELECT:
                if self.selected_indices:
                    self._delete_selected_tps()
                else:
                    self._disable_tp_multiselect()
            else:
                self._enable_tp_multiselect()
        else:
            if mode == UIMode.SAT_MODE_MULTI_SELECT:
                if self.selected_indices:
                    self._delete_selected_sats()
                else:
                    self._disable_sat_multiselect()
            else:
                self._enable_sat_multiselect()

    def _blue(self):
        mode = self.ui_mode
        if mode in (UIMode.TP_MODE_NORMAL, UIMode.TP_MODE_MULTI_SELECT):
            if self.selected_indices:
                self._delete_selected_tps()
            else:
                self._enable_tp_multiselect()
        else:
            if mode == UIMode.SAT_MODE_MULTI_SELECT:
                self._disable_sat_multiselect()
            else:
                self._edit_satellite()